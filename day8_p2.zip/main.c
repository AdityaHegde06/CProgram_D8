/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*Compute value one raised to another*/
#include <stdio.h>

int main()
{
    float x,power;
    int y,i;
    printf("\nEnter the two numbers");
    scanf("%f%d",&x,&y);
    power=i=1;
    
    while(i<=y)
    {
        power=power*x;
        i++;
    }
    printf("%f to the power is %d is %f\n ",x,y,power);

    return 0;
}
