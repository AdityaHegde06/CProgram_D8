/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>

int main()
{
int num,i,fact;
printf("Enter a number\n ");
scanf("%d",&num);
fact=i=1;
while(i<=num)
{
    fact=fact*i;
    i++;
    
}
printf("Factorial value of %d=%d\n",num,fact);
    return 0;
}
