/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//generate all armstrong number between 1 &500
#include <stdio.h>

int main()
{
    int i=1,a,b,c;
    printf("Armstrong numbers between 1 & 500 are\n");
    while(i<500)
    {
        //extract the last digit
        a=i/100;
        b=i%100;
        b=(b-a)/10;/*extract second digit*/
        c=i/100;/*extract first digit */
        if((a*a*a)+(b*b*b)+(c*c*c)==1)
        printf("%d\n",i);
        i++;
    }

    return 0;
}